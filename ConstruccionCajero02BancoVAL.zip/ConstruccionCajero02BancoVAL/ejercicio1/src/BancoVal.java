import java.util.Scanner;

public class BancoVal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cuenta cuenta = new Cuenta(1000000);
        Cajero cajero = new Cajero(cuenta);

        if (cajero.autenticar(scanner)) {
            cajero.mostrarMenu(scanner);
        }

        scanner.close();
    }
}

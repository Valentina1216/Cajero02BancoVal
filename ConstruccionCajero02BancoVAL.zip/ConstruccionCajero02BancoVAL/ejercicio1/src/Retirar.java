import java.util.Scanner;

public class Retirar extends Operacion {
    public Retirar(Cuenta cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar(Scanner scanner) {
        System.out.println("¿Cuánto deseas retirar de tu cuenta?");
        double monto = scanner.nextDouble();
        if (cuenta.retirar(monto)) {
            System.out.println("Retiro hecho exitosamentee. tu saldo actual es: " + cuenta.getSaldo());
        } else {
            System.out.println("Retiro no valido, una disculpa, intentalo más tarde :(.");
        }
    }
}

import java.util.Scanner;

public class Depositar extends Operacion {
    public Depositar(Cuenta cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar(Scanner scanner) {
        System.out.println("¿Cuánto deseas depositar en tu cuenta?");
        double monto = scanner.nextDouble();
        if (monto > 0) {
            cuenta.depositar(monto);
            System.out.println("Depósito hecho exitosamentee. Ahora tu  saldo actual es: " + cuenta.getSaldo());
        } else {
            System.out.println("Monto no válido, vuelvelo a intentar  luego :).");
        }

    }
}

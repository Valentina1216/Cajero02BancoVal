import java.util.Scanner;

public class ConsultarSaldo extends Operacion {
    public ConsultarSaldo(Cuenta cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar(Scanner scanner) {
        System.out.println("Wooow, Tu saldo actual es: " + cuenta.getSaldo());
    }
}

import java.util.Scanner;

public abstract class Operacion {
    protected Cuenta cuenta;

    public Operacion(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    public abstract void ejecutar(Scanner scanner);
}

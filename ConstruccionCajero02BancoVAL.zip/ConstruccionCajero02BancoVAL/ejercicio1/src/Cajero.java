import java.util.Scanner;

public class Cajero {
    private static final int PIN_CORRECTO = 1234;
    private static final int MAX_INTENTOS = 3;
    private Cuenta cuenta;

    public Cajero(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    public boolean autenticar(Scanner scanner) {
        int intentos = 0;
        while (intentos < MAX_INTENTOS) {
            System.out.println("Ingresa tu PIN para poder entrar a tu banco preferido ;) :");
            int pin = scanner.nextInt();
            if (pin == PIN_CORRECTO) {
                return true;
            } else {
                intentos++;
                System.out.println("PIN incorrectooo. Intento " + intentos);
            }
        }
        System.out.println("No eres el dueño, cuenta bloqueada.");
        return false;
    }

    public void mostrarMenu(Scanner scanner) {
        OpcionMenu opcion;
        do {
            System.out.println("""
            "¡Bienvenido a Banco Val :3 !"
                Elige una opción:
                1. Consultar saldo
                2. Retirar dinero 
                3. Depositar dinero
                4. Enviar dinero
                5. Tu Alcancía
                6. Salir de tu banco Val
                """);

            int opcionNum = scanner.nextInt();
            opcion = opcionNum >= 1 && opcionNum <= 6 ? OpcionMenu.values()[opcionNum - 1] : null;

            Operacion operacion = null;

            switch (opcion) {
                case CONSULTAR_SALDO -> operacion = new ConsultarSaldo(cuenta);
                case RETIRAR -> operacion = new Retirar(cuenta);
                case DEPOSITAR -> operacion = new Depositar(cuenta);
                case ENVIAR -> operacion = new Enviar(cuenta);
                case ALCANCIA -> operacion = new Alcancia(cuenta);
                case SALIR -> System.out.println("Nos vemooos");
                default -> System.out.println("Opción no válida");
            }

            if (operacion != null) {
                operacion.ejecutar(scanner);
            }

        } while (opcion != OpcionMenu.SALIR);
    }
}

import java.util.Scanner;

public class Enviar extends Operacion {
    public Enviar(Cuenta cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar(Scanner scanner) {
        System.out.println("¿A qué cuenta deseas enviar el dinero?");
        int cuentaDestino = scanner.nextInt();
        System.out.println("¿Cuánto deseas enviar?");
        double monto = scanner.nextDouble();
        if (cuenta.retirar(monto)) {
            System.out.println("¡Transferencia a cuenta " + cuentaDestino + " exitosa!. tu saldo actual es: " + cuenta.getSaldo());
        } else {
            System.out.println("Lo siento, en este momento no puedes enviar dinero, intentalo más tarde :c .");
        }
    }
}

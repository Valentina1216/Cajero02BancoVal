import java.util.Scanner;

// Tu Alcancia es un lugar especial donde puedas guardar tu dinero y puedas dividir tu capital de forma efectiva.

public class Alcancia extends Operacion {
    public Alcancia(Cuenta cuenta) {
        super(cuenta);
    }

    @Override
    public void ejecutar(Scanner scanner) {
        System.out.println("¿Cuánto deseas guardar en Tu Alcancía?");
        double monto = scanner.nextDouble();
        if (cuenta.retirar(monto)) {
            System.out.println("Guardado en Tu Alcancia con éxito, asi que tienes: " + monto);
            System.out.println(" El saldo que te queda es: " + cuenta.getSaldo());
        } else {
            System.out.println("lo sentimos :(, intentalo más tarde o con otro valor.");
        }
    }
}

